# -*- coding: utf-8 -*-
# This file is part of Xpra.
# Copyright (C) 2013 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from xpra.x11.shadow_x11_server import ShadowX11Server

ShadowServer = ShadowX11Server
